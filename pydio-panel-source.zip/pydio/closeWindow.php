<?php
	$glueCode = "GLUE_CODE_ADDRESS";
	$secret = "myprivatesecret";
	define('AJXP_EXEC', true);
	global $AJXP_GLUE_GLOBALS;
	$AJXP_GLUE_GLOBALS = array();
	$AJXP_GLUE_GLOBALS["secret"] = $secret;
	$AJXP_GLUE_GLOBALS["plugInAction"] = "logout";
  include($glueCode);
?>  
<script>window.close();</script>