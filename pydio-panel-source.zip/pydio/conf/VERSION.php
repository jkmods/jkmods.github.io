<?php
define("AJXP_VERSION", "6.0.8");
define("AJXP_VERSION_DATE", "2015-06-29");
define("AJXP_VERSION_REV", "2dc263a");
define("AJXP_VERSION_DB", "60");
