<?php
/*
* Copyright 2007-2013 Charles du Jeu - Abstrium SAS <team (at) pyd.io>
* This file is part of Pydio.
*
* Pydio is free software: you can redistribute it and/or modify
* it under the terms of the GNU Affero General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Pydio is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Affero General Public License for more details.
*
* You should have received a copy of the GNU Affero General Public License
* along with Pydio.  If not, see <http://www.gnu.org/licenses/>.
*
* The latest code can be found at <http://pyd.io/>.
*/
$mess=array(
"Mysql Database" => "Mysql Database",
"This driver can browse and update tables and records in a MySQL database, kind of phpMyAdmin." => "Questo driver consente di esplorare ed aggiornare tabelle e record in un database MySQL (come il phpMyAdmin).",
"Host" => "Host",
"Host to the MySQL Server" => "Host del Server MySQL",
"Database" => "Database",
"Database name" => "Nome Database",
"User" => "Utente",
"User name (must have privileges to access this db)" => "Username (deve avere privilegi di accesso a questo database)",
"Password" => "Password",
"User password" => "Password dell'Utente",
"Pattern" => "Modello",
"If not empty, only tables beginning with such a prefix will be displayed." => "Se non è vuoto, verranno mostrate solo le tabelle che iniziano con questo prefisso.",
"Repository Commons" => "Repository Commons",
"Default Rights" => "Privilegi Default",
);
