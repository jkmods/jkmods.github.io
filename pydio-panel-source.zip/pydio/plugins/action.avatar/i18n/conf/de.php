<?php
/*
* Gravatar plugin for AjaXplorer
*/
$mess=array(
"Avatars" => "Avatar",
"Get user avatar from Gravatar/Libravatar" => "Avatar von Gravatar/Libravatar holen.",
"Gravatar type" => "Gravatar-Typ",
"Provider" => "Anbieter",
"Choose an avatar web service" => "Wählen Sie einen Avatar-Web-Service",
);