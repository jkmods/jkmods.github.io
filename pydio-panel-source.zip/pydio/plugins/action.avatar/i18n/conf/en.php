<?php
/*
* Gravatar plugin for AjaXplorer
*/
$mess=array(
"Avatars" => "Avatars",
"Get user avatar from Gravatar/Libravatar" => "Get user avatar from Gravatar/Libravatar",
"Gravatar type" => "Gravatar type",
"Provider" => "Provider",
"Choose an avatar web service" => "Choose an avatar web service",
);