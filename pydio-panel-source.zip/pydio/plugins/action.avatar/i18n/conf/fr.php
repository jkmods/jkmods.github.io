<?php
/*
* Gravatar plugin for AjaXplorer
*/
$mess=array(
"" => "Avatars",
"Get user avatar from Gravatar/Libravatar" => "Obtenir des avatars depuis Gravatar / Libravatar",
"Gravatar type" => "Type Gravatar",
"Provider" => "Fournisseur",
"Choose an avatar web service" => "Choisissez un service web d'avatar",
);