<?php
/*
* Gravatar plugin for AjaXplorer
*/
$mess=array(
"Avatars" => "Avatars",
"Get user avatar from Gravatar/Libravatar" => "Utilizza un avatar da Gravatar/Libravatar",
"Gravatar type" => "Tipo Gravatar",
"Provider" => "Provenienza",
"Choose an avatar web service" => "Scegli un servizio web per avatar",
);